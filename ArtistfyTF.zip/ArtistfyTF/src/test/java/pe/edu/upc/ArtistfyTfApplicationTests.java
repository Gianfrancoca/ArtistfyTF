package pe.edu.upc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtistfyTfApplicationTests {

	@Test
	void contextLoads() {
	}

}
